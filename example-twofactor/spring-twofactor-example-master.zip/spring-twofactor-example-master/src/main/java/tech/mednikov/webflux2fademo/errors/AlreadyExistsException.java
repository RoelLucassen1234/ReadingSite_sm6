package tech.mednikov.webflux2fademo.errors;

public class AlreadyExistsException extends RuntimeException{
}
