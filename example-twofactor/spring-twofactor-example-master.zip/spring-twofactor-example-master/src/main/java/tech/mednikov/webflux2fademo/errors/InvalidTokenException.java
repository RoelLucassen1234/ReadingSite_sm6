package tech.mednikov.webflux2fademo.errors;

public class InvalidTokenException extends RuntimeException {
}
