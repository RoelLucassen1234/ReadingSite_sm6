package tech.mednikov.webflux2fademo.errors;

public class LoginDeniedException extends RuntimeException{
}
