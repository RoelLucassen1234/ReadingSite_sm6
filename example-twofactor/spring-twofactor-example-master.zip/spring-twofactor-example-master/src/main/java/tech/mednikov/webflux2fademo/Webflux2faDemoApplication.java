package tech.mednikov.webflux2fademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webflux2faDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Webflux2faDemoApplication.class, args);
	}

}
