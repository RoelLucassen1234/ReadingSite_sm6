package tech.mednikov.webflux2fademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webflux2faDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
